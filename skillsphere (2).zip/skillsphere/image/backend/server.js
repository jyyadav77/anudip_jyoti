
const express = require("express");
const mongoose = require("mongoose");
const bcrypt = require("bcryptjs");
const bodyParser = require("body-parser");
const cors = require("cors");
const jwt = require("jsonwebtoken");
const path=require("path");

const app = express();
const port = process.env.PORT || 5000;

// Middleware
app.use(cors());
app.use(bodyParser.json());  // Parse JSON requests

// MongoDB connection
mongoose.connect("mongodb://localhost:27017/SY", {
  useNewUrlParser: true,
  useUnifiedTopology: true,
})
.then(() => {
  console.log("Connected to MongoDB");
})
.catch(err => {
  console.log("Error connecting to MongoDB:", err);
});

app.get("/", (req, res) => {
  res.sendFile(path.join(__dirname,  "/hp.html"));
});



app.get("/reg", (req, res) => {
    res.sendFile(path.join(__dirname, "/reg.html"));
  });
// User Schema
const userSchema = new mongoose.Schema({
  name: { type: String, required: true, maxlength: 32 },
  email: { type: String, required: true, unique: true },
  contact: { type: String, required: true, length: 10 },
  password: { type: String, required: true, minlength: 8, maxlength: 12 },
});

const User = mongoose.model("User", userSchema);

// Registration route
app.post("/REGIS", async (req, res) => {
  const { name, email, contact, password, confirmPassword } = req.body;

  // Check if passwords match
  if (password !== confirmPassword) {
    return res.status(400).json({ success: false, message: "Passwords do not match." });
  }

  // Check if email already exists
  const existingUser = await User.findOne({ email });
  if (existingUser) {
    return res.status(400).json({ success: false, message: "Email already in use." });
  }

  // Hash the password
  const hashedPassword = await bcrypt.hash(password, 10);

  // Create new user
  const newUser = new User({
    name,
    email,
    contact,
    password: hashedPassword,
  });

  try {
    // Save the user to the database
    await newUser.save();
    res.status(200).json({ success: true, message: "Registration successful!" });
  } catch (err) {
    console.error("Error registering user:", err);
    res.status(500).json({ success: false, message: "Error registering user." });
  }
});

// Start the server
app.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}`);
});
