const mongodb = require('mongoose')

// Connection URL
/*const mongoose = 'mongodb+srv://sagar123:vsagar214@cluster1.5xhni.mongodb.net/';
const dbName = 'vsagar';

// Create a new MongoClient
const client = new MongoClient(mongoose, { useUnifiedTopology: true });

async function main() {
  try {
    // Connect to the MongoDB server
    await client.connect();
    console.log('Connected successfully to MongoDB');

    const db = client.db(dbName);

  } catch (err) {
    console.error(err);
  } finally {
    // Close the connection
    await client.close();
  }
}*/
mongodb.connect('mongodb+srv://sagar123:vsagar214@cluster1.5xhni.mongodb.net/', {
  useNewUrlParser: true,
  useUnifiedTopology: true
}).then(() => {
  console.log('Connected to MongoDB');
}).catch((err) => {
  console.error('Error connecting to MongoDB', err);
});

const DataSchema = new mongodb.Schema({
  name: String,
  email :String,
  department : String,
  cgpa : Number,
  password : String
});

// Create a Mongoose model
const Data = mongodb.model('Data', DataSchema);


/*main().catch(console.error);*/

module.exports=mongodb;
