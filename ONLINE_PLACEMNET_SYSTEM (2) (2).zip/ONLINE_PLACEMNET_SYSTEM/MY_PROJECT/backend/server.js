const express = require("express");
const bodyParser = require("body-parser");
const path = require("path");
const mongoose = require("mongoose");
const bcrypt = require("bcrypt");
const session = require("express-session");
const multer = require("multer");
const nodemailer = require('nodemailer');
const cors = require("cors");
const crypto = require("crypto");
const app = express();

// emailConfig.js
/*// Replace with your SMTP service credentials
const transporters = nodemailer.createTransport({
  service: 'gmail', // or your preferred email service
  auth: {
    user: process.env.EMAIL = 'sagaryadav23july20004@mail.com'  // Your email (from env or hardcoded)
    pass: process.env.PASSWORD = 'mrqf bwpb uygagspu' // Your email password (from env or hardcoded)
  }
});*/


// Middleware
app.use(bodyParser.urlencoded({ extended: true }));
app.use(cors());
app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, "../frontend/")));

// Session middleware
app.use(session({
  secret: 'your_secret_key', // Replace with your own secret key
  resave: false,
  saveUninitialized: true
}));

app.get("/", (req, res) => {
  res.sendFile(path.join(__dirname, "../frontend/HP.html"));
});
// Serve the placement registration page
app.get("/reg", (req, res) => {
  res.sendFile(path.join(__dirname, "../frontend/reg.html"));

});
app.get("/apply", (req, res) => {
  res.sendFile(path.join(__dirname, "../frontend/AC.html"));

});
app.get("/recu", (req, res) => {
  res.sendFile(path.join(__dirname, "../frontend/Recu.html"));

});
app.get("jobs", (req, res) => {
  res.sendFile(path.join(__dirname, "../frontend/JBS.html"));

});
app.get("/forgot-password", (req, res) => {
  res.sendFile(path.join(__dirname, "../frontend/for.html"));

});
// Connect to MongoDB
mongoose.connect("mongodb://localhost:27017/normal")
  .then(() => console.log("Connected to MongoDB"))
  .catch(err => console.error("Error connecting to MongoDB", err));

// User Schema
// User schema
const UserSchema = new mongoose.Schema({
  name: String,
  email: { type: String, unique: true, required: true },
  password: String,
});

const User = mongoose.model('User', UserSchema);

let otpStore = {}; // Temporary storage for OTPs

// Configure your email transport
let transporter = nodemailer.createTransport({
  service: 'Gmail', // Use your email service
  auth: {
      user: 'sagaryadav23july20004@gmail.com', // Your email
      pass: 'nusi vjhw gnao jtnx', // Your email password
  },
});

/*async function sendOtp(email) {
  const otp = Math.floor(100000 + Math.random() * 900000).toString(); // Generate a 6-digit OTP
  otpStore[email] = otp; // Store OTP in memory

  // Configure your email transport
  let transporter = nodemailer.createTransport({
      service: 'Gmail', // Use your email service
      auth: {
          user: 'sagaryadav23july20004@gmail.com', // Your email
          pass: 'ykxn fwmq iehd bkao', // Your email password
      },
  });

  await transporter.sendMail({
      from: '', // Your email
      to: email,
      subject: 'Your OTP for Password Reset',
      text: `Your OTP is: ${otp}. It is valid for 10 minutes.`,
  });
}*/

// Route to request password reset
/*app.post('/forgot-password', async (req, res) => {
  const { email } = req.body;

  // Check if the user exists
  const user = await Student.findOne({ email });
  if (!user) {
      return res.status(404).json({ message: "Email not found." });
  }
  async function sendOtp(email) {
    const otp = Math.floor(100000 + Math.random() * 900000).toString(); // Generate a 6-digit OTP
    otpStore[email] = otp;
  };
  await sendOtp(email);
  res.json({ message: "OTP sent to your email." });
  

 await transporter.sendMail({
    from: 'sagaryadav23july20004@gmail.com', // Your email
    to: email,
    subject: 'Your OTP for Password Reset',
    text: `Your OTP is: ${otp}. It is valid for 10 minutes.`,
});
});*/


app.post('/forgot-password', async (req, res) => {
  const { email } = req.body;

  // Check if the user exists
  const user = await Student.findOne({ email });
  if (!user) {
    return res.status(404).json({ message: "Email not found." });
  }

  async function sendOtp(email) {
    const otp = Math.floor(100000 + Math.random() * 900000).toString(); // Generate a 6-digit OTP
    otpStore[email] = otp; // Store the OTP for the email
    return otp; // Return the OTP
  };

  const otp = await sendOtp(email); // Get the OTP
  res.json({ message: "OTP sent to your email." });

  await transporter.sendMail({
    from: 'sagaryadav23july20004@gmail.com', // Your email
    to: email,
    subject: 'Your OTP for Password Reset',
    text: `Your OTP is: ${otp}. It is valid for 10 minutes.`,
  });
});

// Endpoint to hire an applicant
app.post('/hire', (req, res) => {
  const { name, email, phone, resume } = req.body;

  const subject = `Congratulations ${name}, You've Been Hired!`;
  const body = `Dear ${name},\n\nCongratulations! You have been hired. Please find the details below:\n\nName: ${name}\nEmail: ${email}\nPhone: ${phone}\n\nBest regards,\nYour Company`;

  const mailOptions = {
      from: 'sagaryadav23july20004@gmail.com',
      to: email,
      subject: subject,
      text: body,
  };

  transporter.sendMail(mailOptions, (error, info) => {
      if (error) {
          return res.status(500).send('Error sending email: ' + error);
      }
      res.send(`Email sent: ${info.response}`);
  });
});

// Route to verify OTP and reset password
app.post('/verify-otp', async (req, res) => {
  const { email, otp, newPassword } = req.body;

  // Verify OTP
  if (otpStore[email] && otpStore[email] === otp) {
      // Update the user's password in the database
      const hashedPassword = await bcrypt.hash(newPassword, 10);
      await Student.updateOne({ email }, { password: hashedPassword });

      delete otpStore[email]; // Clear OTP after use
      res.json({ message: "Password reset successfully." });
  } else {
      res.status(400).json({ message: "Invalid OTP." });
  }
});




// Student Schema
// Student Schema
/*const StudentSchema = new mongoose.Schema({
  name: String,
  email: { type: String, unique: true, required: true },
  contact: String,
  password: String,
  role: {
    type: String,
    enum: ['Student', 'Recruiter', 'TPO'], // Specify the allowed roles
    default: 'Student' // Default value
  }
});

const Student = mongoose.model("Student", StudentSchema);*/

const StudentSchema = new mongoose.Schema({
  name: { type: String, required: true },
  email: { type: String, unique: true, required: true },
  contact: { type: String, required: true },
  password: { type: String, required: true },
  role: {
    type: String,
    enum: ['Student', 'Recruiter', 'TPO', 'Admin'], // Specify allowed roles
    required: true // Role is now mandatory, no default value
  },
  // Optional role-specific fields
  studentSpecificField: { type: String },  // Field specific to Student role
  recruiterSpecificField: { type: String }, // Field specific to Recruiter role
  tpoSpecificField: { type: String }, // Field specific to TPO role
  adminSpecificField: { type: String } // Field specific to Admin role
});

const Student = mongoose.model("Student", StudentSchema);



// Login Route

app.post("/REGIS", async (req, res) => {
  const { name, email, contact, password, role } = req.body; // Capture role from request body

  if (!role) {
    return res.status(400).json({ success: false, message: "Role is required." });
  }

  try {
    const hashedPassword = await bcrypt.hash(password, 10);

    // Check if the email is already registered
    const existingUser = await Student.findOne({ email });
    if (existingUser) {
      return res.status(400).json({ success: false, message: "Email already registered" });
    }

    // Create a new user
    const newUser = new Student({
      name,
      email,
      contact,
      password: hashedPassword,
      role // Save the role
    });

    // Save the new user
    await newUser.save();
    res.status(200).json({ success: true, message: "Registration successful" });

  } catch (error) {
    console.error("Error saving data:", error);
    res.status(500).json({ success: false, message: "Failed to register" });
  }
});

app.post('/login', async (req, res) => {
  const { email, password, role } = req.body;

  try {
    // Convert role to lowercase for case-insensitive matching
    const normalizedRole = role.toLowerCase();

    // Find the user in the Student collection by email and role (case-insensitive)
    const user = await Student.findOne({
      email,
      role: { $regex: new RegExp(normalizedRole, 'i') } // Case-insensitive role matching
    });

    if (!user) {
      console.log('User not found for the specified email or role');
      return res.status(401).json({ success: false, message: 'Incorrect email or role specified' });
    }

    // Compare the password
    const isPasswordValid = await bcrypt.compare(password, user.password);
    if (!isPasswordValid) {
      return res.status(401).json({ success: false, message: 'Incorrect password.' });
    }

    // Store user information in session
    req.session.user = {
      email: user.email,
      contact: user.contact,
      role: user.role // Use the role from the database
    };

    // Redirect URL based on the user's role
    let redirectUrl;
    if (user.role === 'Student') {
      redirectUrl = '/reg.html';
    } else if (user.role === 'Recruiter') {
      redirectUrl = '/Recu.html';
    } else if (user.role === 'TPO') {
      redirectUrl = '/TPO.html';
    } else if (user.role === 'Admin') {
      redirectUrl = '/Ad.html';
    }

    res.status(200).json({ success: true, redirectUrl });
  } catch (error) {
    console.error('Error during login:', error);
    res.status(500).json({ success: false, message: 'Failed to login' });
  }
});



// Profile Update Route
app.post('/saveProfile', async (req, res) => {
  const { email, contact } = req.body;

  try {
    const user = await Student.findOne({ email });

    if (!user) {
      return res.status(401).json({ success: false, message: 'User not found' });
    }

    user.contact = contact; // Update as needed
    await user.save();

    req.session.user.contact = contact;

    res.status(200).json({ success: true, message: 'Profile updated successfully' });
  } catch (error) {
    console.error('Error updating profile:', error);
    res.status(500).json({ success: false, message: 'Server error updating profile' });
  }
});



// Job Schema
const jobSchema = new mongoose.Schema({
  jb: {
    type: String,
    required: true,
  },
  dec: {
    type: String,
    required: true,
  },
  sr: {
    type: String,
    required: true,
  },
  ps: {
    type: String,
    required: true,
  }
});

const Job = mongoose.model('Job', jobSchema);

// Posting a Job
app.post('/recu', async (req, res) => {
  const { jb, dec, sr, ps } = req.body;

  if (!jb || !dec || !sr || !ps) {
    return res.status(400).json({ success: false, message: 'All fields are required' });
  }

  try {
    const newJob = new Job({ jb,dec,sr,ps });
    await newJob.save();
    res.status(201).json({ success: true, message: 'Job posted successfully!' });
  } catch (error) {
    console.error('Error posting job:', error);
    res.status(500).json({ success: false, message: 'Server error. Please try again later.' });
  }
});

// Get all jobs
app.get('/jobs', async (req, res) => {
  try {
    const jobs = await Job.find();
    res.json(jobs);
  } catch (error) {
    console.error(error);
    res.status(500).send('Server error');
  }
});
/*// Set up multer for file uploads
const storages = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, 'uploads/'); // Specify the uploads folder
  },
  filename: (req, file, cb) => {
    cb(null, Date.now() + path.extname(file.originalname));
  }
});
const uploads = multer({ storage });*/

/*// Handle file upload
app.post('/apply', upload.single('resume'), async (req, res) => {
  const { name, email, phone } = req.body;
  const resume = req.file.filename;

  try {
    const application = new apply({
      name,
      email,
      phone,
      resume
    });
    await application.save();
    res.status(200).json({ success: true, message: 'Application submitted successfully!' });
  } catch (error) {
    console.error('Error saving application:', error);
    res.status(500).json({ success: false, message: 'Failed to submit application.' });
  }
});*/

const applySchema = new mongoose.Schema({
  name: String,
  email: String,
  phone: String,
  resume: String // Storing the file path
});

const Apply = mongoose.model('apply', applySchema);

// Set up multer for file uploads (using your custom path)
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, 'C:/Users/jy865/OneDrive/Pictures/Screenshots/'); // Specify the uploads folder
  },
  filename: (req, file, cb) => {
    // Save the file with a timestamp to avoid conflicts, keeping the original extension
    cb(null, Date.now() + path.extname(file.originalname)); 
  }
});
const upload = multer({ storage });

// Serve static files (e.g., your HTML, CSS, and JS from 'public' folder)
app.use(express.static('frontend'));

// Serve uploaded files
app.use('/screenshots', express.static('C:/Users/jy865/OneDrive/Pictures/Screenshots/'));

// Middleware to parse JSON bodies
app.use(express.json());

// Handle form submission (POST request)
app.post('/apply', upload.single('resume'), async (req, res) => {
  const { name, email, phone } = req.body;
  const resume = req.file.filename; // Get the uploaded file's name

  try {
    // Save the application data to the database
    const newApply = new Apply({
      name,
      email,
      phone,
      resume
    });

    await newApply.save(); // Save the application data

    res.status(200).json({ success: true, message: 'Application submitted successfully!' });
  } catch (error) {
    console.error('Error saving application:', error);
    res.status(500).json({ success: false, message: 'Failed to submit application.' });
  }
});





app.get('/tpo', async (req, res) => {
  try {
    const jobs = await Job.find();
    res.json(jobs);
  } catch (error) {
    console.error(error);
    res.status(500).send('Server error');
  }
});


const DepartmentSchema = new mongoose.Schema({
  name: { type: String, required: true },
});
const Department = mongoose.model('Department', DepartmentSchema);

// Add department route
app.post('/addDepartment', async (req, res) => {
  const { deptName } = req.body;

  try {
      // Check if the department already exists
      const existingDept = await Department.findOne({ name: deptName });
      if (existingDept) {
          return res.status(400).json({ message: 'Department already exists.' });
      }

      const newDepartment = new Department({ name: deptName });
      await newDepartment.save();
      res.status(201).json({ message: 'Department added successfully.' });
  } catch (error) {
      console.error('Error adding department:', error);
      res.status(500).json({ message: 'Error adding department.' });
  }
});

// Get all departments route
app.get('/departments', async (req, res) => {
  try {
      const departments = await Department.find();
      res.status(200).json(departments);
  } catch (error) {
      console.error('Error fetching departments:', error);
      res.status(500).json({ message: 'Error fetching departments.' });
  }
});

// Fetch all applications
app.get('/applications', async (req, res) => {
  try {
    const applications = await Apply.find(); // Fetch all applications from the database
    res.status(200).json(applications);
  } catch (error) {
    console.error('Error fetching applications:', error);
    res.status(500).json({ message: 'Failed to fetch applications.' });
  }
});
app.get('/STUDENT', async (req, res) => {
  try {
    const applications = await register.find(); // Fetch all student applications from the 'register' collection
    res.status(200).json(applications); // Send the applications as JSON with a 200 OK status
  } catch (error) {
    console.error('Error fetching Student:', error); // Log any errors that occur
    res.status(500).json({ message: 'Failed to fetch applications.' }); // Send a 500 Internal Server Error if something goes wrong
  }
});
app.get('/REGISTER', async (req, res) => {
  try {
      const applications = await Student.find({ role: 'Student' }); // Fetch only student applications
      res.status(200).json(applications); // Send the applications as JSON with a 200 OK status
  } catch (error) {
      console.error('Error fetching register:', error); // Log any errors that occur
      res.status(500).json({ message: 'Failed to fetch applications.' }); // Send a 500 Internal Server Error if something goes wrong
  }
});
// Define register Schema
const registerSchema = new mongoose.Schema({
  name: { type: String, required: true, minlength: 3 },
  email: { type: String, unique: true },
  department: { type: String, required: true },
  cgpa: { type: Number, required: true, min: 1, max: 10 },
  skill: { type: String, required: true },
  contact: { type: String, required: true, minlength: 10, maxlength: 10 },
});

// Create Student Model
const register = mongoose.model('register', registerSchema);

// Registration Endpoint
app.post('/reg', async (req, res) => {
  const { name, email, department, cgpa, skill, contact } = req.body;

  // Server-side validation
  if (!name || !/^[a-zA-Z\s]+$/.test(name)) {
    return res.status(400).json({ success: false, message: 'Invalid name' });
  }
  if (!email || !/\S+@\S+\.\S+/.test(email)) {
    return res.status(400).json({ success: false, message: 'Invalid email' });
  }
  if (!department) {
    return res.status(400).json({ success: false, message: 'Invalid department' });
  }
  if (cgpa < 1 || cgpa > 10) {
    return res.status(400).json({ success: false, message: 'Invalid CGPA' });


  }
  if (!skill) {
    return res.status(400).json({ success: false, message: 'Invalid department' });
  }

  if (!contact || !/^[0-9]{10}$/.test(contact)) {
    return res.status(400).json({ success: false, message: 'Invalid contact number' });
  }


  try {
    const newregister = new register({
      name,
      email,
      department,
      cgpa,
      skill,
      contact,
    });
    const checkEmail= register.findOne({email})
   
    await newregister.save();
    res.json({ success: true, message: 'Registration successful!' });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
});
// Start the server
const PORT = process.env.PORT || 9000;
app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
